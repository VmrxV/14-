﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _14._4
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			double y = 0;

			for (int x = -22; (x <= 22); x++)
			{
				y = Math.Pow(x, 2);
				chart1.Series["porabola"].Points.AddXY(x, y);

				y = Math.Sin(Math.PI / 5 * x)*100;
				chart1.Series["sin(x)"].Points.AddXY(x, y);

				y = Math.Cos(Math.PI / 5 * x)*100;
				chart1.Series["cos(x)"].Points.AddXY(x, y);
			}
		}
	}
}
