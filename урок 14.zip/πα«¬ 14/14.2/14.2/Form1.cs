﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _14._2
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			Bitmap mbit = new Bitmap(pictureBox1.Width, pictureBox1.Height);
			Graphics g;
			g = Graphics.FromImage(mbit);
			
			Pen mypen = new Pen(Color.Red);
			g.DrawEllipse(mypen, 55, 55, 100, 55);
			mypen = new Pen(Color.Navy);
			g.DrawLine(mypen, 30, 55, 300, 55);
			g.FillRectangle(Brushes.Blue, 90, 100, 300, 100);
			g.DrawString("Paint", new Font("Arial", 22), new SolidBrush(Color.Green), 10, 10);
			pictureBox1.Image = mbit;
		}
	}
}
